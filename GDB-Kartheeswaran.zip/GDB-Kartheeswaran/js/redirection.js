function createinstitution(){
    window.location.href ="../vendoradmin/createinstitution.html";
};
function manageinstitution(){
    window.location.href ="../vendoradmin/manageinstitution.html";
};
function ICUregistration(){
    window.location.href ="../Tenantadmin/icuregistration.html";
};
function Deviceregistration(){
   window.location.href ="../vendoradmin/Deviceregistration.html"; 
};


function icumanagement(){ 
    window.location.href ="../Tenantadmin/ICUManagement.html";
};
function dashboard(){
    window.location.href ="dashboard.html";
};
function createuser(){
    window.location.href ="../Tenantadmin/usermanagement.html";
};
function bedview(){
    window.location.href ="../Tenantadmin/Bedview.html";
    //window.location.href ="../vendoradmin/Bedview.html";
};




function createuser1(){
   window.location.href ="../Tenantadmin/createuser.html"; 
};
function manageuser(){
   window.location.href ="../Tenantadmin/manageuser.html"; 
};
function patientregistration(){
     window.location.href ="../Tenantadmin/patientregistration.html"; 
}
function videochat(){
    window.location.href ="../Tenantadmin/videoandchat.html"; 
}

function callcenter(){
    window.location.href ="../Tenantadmin/callcenter.html"; 
}
