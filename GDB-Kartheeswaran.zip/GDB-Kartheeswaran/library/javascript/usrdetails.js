function gettoken() {
    var token = localStorage.getItem('access_token');
    access_token1 = token;
}
;
var vendorEditProfile = function() {
	$.support.cors = true;
	$.ajax({
		url :'/AAA/useraccount/getCurrentUser?access_token='+access_token1,
		type : 'GET',
		processData : false,
		async : false,
		success : function(data) {
			$("#username").append(data);
                        $("#username").text(data);
		}
	});
};