Dropzone.autoDiscover = false;
var id;
(function () {
    var upload = document.getElementById("upload"),
            authToken = localStorage.getItem('access_token'),
    clear = document.getElementById("clear"),
    dropzone = new Dropzone(".dropzone", {
        url: '/doc/upload?access_token='+authToken+'&id='+id,
        uploadMultiple: true,
        autoProcessQueue: false,
        addRemoveLinks: true,
        parallelUploads: 1000
    });
    upload.onclick = function () {
         var description = $("#description").val();
        if (description !== "") {
             $("#descriptionfail").text("");
            $("#descriptionfail").hide();
        var registrationform = document.getElementById('validate_wizard');
        var formdata = ConvertFormToJSON(registrationform);
        id = formdata.patientid;
        var queuedFiles = dropzone.getQueuedFiles();
        if (!(queuedFiles.length > 0)) {
            return;
        }
        var url;
            //Import DICOM only
            url = '/doc/upload?access_token=' + authToken +'&id='+id+'&desc='+description ;
            dropzone.options.url = url;
            dropzone.processQueue();
        }else{
              $("#descriptionfail").text("Please give a file description");
            $("#descriptionfail").show();
        }
    };
    clear.onclick = function () {
        dropzone.removeAllFiles(false);
    };
}
());
