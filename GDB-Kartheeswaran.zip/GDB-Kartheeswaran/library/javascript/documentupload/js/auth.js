/* global Highcharts, authToken */
(function ($) {
    $(document).ready(function () {
        authToken = JSON.parse(localStorage.getItem('token'));
        if (authToken !== null) {
            verifyAuthentication(authToken);
            getAETitle(authToken);
        }
        else {
            window.location.href = '/';
        }
    });
    function getAETitle(authToken) {
        var url = getHostName() + '/StellarPACSWeb-RS/rs/settings/getMyAE?access_token=' + authToken.access_token;
        $.ajax({
            url: url,
            type: "GET",
            success: function (data, textStatus, message)
            {
                //data: return data from server
                if (message.status === 200) {
                    if (data !== null) {
                        aeTitle = data;
                    }
                }
            },
            error: function (message, textStatus, errorThrown)
            {
                localStorage.clear();
                window.location.href = '/';
            }
        });
    }
    function verifyAuthentication(authToken) {
        var oauthServer = getHostName() + '/Stellar-OauthServer/';
        var url = oauthServer + 'verify?access_token=' + authToken.access_token;
        $.ajax({
            url: url,
            type: "GET",
            success: function (data, textStatus, message)
            {
                //data: return data from server
                if (message.status === 200) {
                    if (data !== null) {
                        var name = checkUserName(data);
                        $("#loggedUserName").text(name);
                        aeTitle = data.tenantId;
                        $("#institutionName").text(data.tenantName);
                        var avatarURL = getHostName() + '/StellarPACSAdmin-RS/resources/user/getuseravatar?username=' + data.username + '&access_token=' + authToken.access_token;
                        $("#avatarThumb").attr("src", avatarURL);
                        var userAuth = checkAuthority(data);
                        showMoreMenuWindow(data.authorities);
                        if (userAuth === false) {
                            logout();
                        }
                    }
                }
                else {
                    localStorage.clear();
                    window.location.href = '/';
                }
            },
            error: function (message, textStatus, errorThrown)
            {
                localStorage.clear();
                window.location.href = '/';
            }
        });
    }

}(jQuery));
var getHostName = function () {
    var parser = document.createElement('a');
    parser.href = window.location.href;
    var URL = parser.protocol + '//' + parser.hostname + ':' + parser.port;
    return  URL;
};
function logout() {
    var resourceServer = getHostName() + '/Stellar-OauthServer/logout'
    $.ajax({
        url: resourceServer + 'logout',
        headers: {'Authorization': authToken.access_token},
        type: 'GET',
        success: function (data, textStatus, jqXHR) {
            localStorage.clear();
            window.location.href = "/";
        },
        error: function (jqXHR, textStatus, errorThrown) {
            localStorage.clear();
            window.location.href = '/';
        }

    });
}
function showMoreMenuWindow(featureList) {
    var features = [];
    $.each(featureList, function (i, item) {
        features.push(item.authority);
    });
    var list = features;
    var uniqueFeature = list.filter(onlyUnique);
    var feature = '<div class="feature"><a href="/dashboard/" style="text-decoration:none;"><img  src="images/features/home.png" width="42" height="42"/> <br><span align="center">Dashboard</span></a></div>';
    $("#userPrivilage").append(feature);
    $.each(uniqueFeature, function (i, item) {
        if (item === "User Management" || item === "DICOM Service Configuration" || item === "DICOM Routing" || item === "Archive") {
            if (adminFeature === false) {
                adminFeature = true;
                var featureUrl = getFeatureUrl(item);
                var feature = '<div class="feature"><a href="/StellarPACSAdmin-Web/app/#/' + featureUrl + '" style="text-decoration:none;"><img  src="images/features/user.png" width="42" height="42"/> <br><span align="center">Admin</span></a></div>';
                $("#userPrivilage").append(feature);
            }
        }
        else if (item === "Create Order" || item === "Modify Order" || item === "Execute Order" ||
                item === "Patient Registration" || item === "Schedule Order"
                || item === "Schedule Report" || item === "Walkin Schedule") {
            if (orderFeature === false) {
                orderFeature = true;
                var featureUrl = getFeatureUrl(item);
                var feature = '<div class="feature"><a href="/StellarRIS-Web/app/#/' + featureUrl + '" style="text-decoration:none;"><img  src="images/features/order.png" width="42" height="42"/> <br><span align="center">RIS</span></a></div>';
                $("#userPrivilage").append(feature);
            }
        }
        else if (item === "View Study") {
            var feature = '<div class="feature"><a href="/StellarPACSWeb/patientbrowser/" style="text-decoration:none;"><img  src="images/features/patientbrowser.png" width="42" height="42"/> <br><span align="center">Patient Browser</span></a></div>';
            $("#userPrivilage").append(feature);
        }
        else if (item === "Create Report Template" || item === "Modify Report Template" ||
                item === "Approve Report Template") {
            if (reportTemplateFeature === false) {
                reportTemplateFeature = true;
                var feature = '<div class="feature"><a href="/StellarPACSReport" style="text-decoration:none;"><img  src="images/features/reporttemplate.png" width="42" height="42"/> <br><span align="center">Report<br>Template</span></a></div>';
                $("#userPrivilage").append(feature);
            }
        }
        else if (item === "Audit") {
            var feature = '<div class="feature"><a href="/StellarPACSAdmin-Web/app/#/auditlog" style="text-decoration:none;"><img  src="images/features/audit.png" width="42" height="42"/> <br><span align="center">Audit</span></a></div>';
            $("#userPrivilage").append(feature);
        }
    });
}
function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}
function checkUserName(Model) {
    if (Model.firstName === "" || Model.lastName === "") {
        if (Model.firstName !== "" && Model.lastName === "") {
            return Model.firstName;
        }
        if (Model.firstName === "" && Model.lastName !== "") {
            return Model.lastName;
        }
        if (Model.firstName === "" && Model.lastName === "") {
            return Model.username;
        }
    }
    else if (Model.firstName === null || Model.lastName === null) {
        if (Model.firstName !== null && Model.lastName === null) {
            return Model.firstName;
        }
        if (Model.firstName === null && Model.lastName !== null) {
            return Model.lastName;
        }
        if (Model.firstName === null && Model.lastName === null) {
            return Model.username;
        }
    }
    else {
        return Model.firstName + Model.lastName;
    }
}
function checkAuthority(Model) {
    var privilage = Model.authorities;
    var status = false;
    for (var i = 0; i < privilage.length; i++) {
        if (privilage[i].authority === "Import") {
            status = true;
            break;
        }
    }
    return status;
}
function getFeatureUrl(feature) {
    var url = "";
    if (feature === "User Management") {
        url = 'user';
    }
    else if (feature === "DICOM Service Configuration") {
        url = 'serverconfig';
    }
    else if (feature === "DICOM Routing") {
        url = 'routing';
    }
    else if (feature === "Archive") {
        url = 'archive';
    }
    else if (feature === "Create Order" || feature === "Modify Order") {
        url = 'patient';
    }
    else if (feature === "Execute Order") {
        url = 'modality';
    }
    else if (feature === "Patient Registration") {
        url = 'addpatient';
    }
    else if (feature === "Schedule Order") {
        url = 'order';
    }
    else if (feature === "Schedule Report") {
        url = 'report';
    }
    else if (feature === "Walkin Schedule") {
        url = 'walkinschedule';
    }
    return url;
}
function showVersionDialog() {
    $.ajax({
        url: getHostName() + '/StellarPACSAdmin-RS/getproductinfo?access_token=' + authToken.access_token,
        type: 'GET',
        success: function (data) {
            $(".modal #productDetail").text(data.productname + "  " + data.productversion);
            $("#versionModal").modal("show");
        },
        error: function (jqXHR) {
            if (jqXHR.status === 401 || jqXHR.status === 403) {
                localStorage.clear();
                window.location.href = '/';
            }
            else {
                console.log(jqXHR.status);
            }
        }

    });

}