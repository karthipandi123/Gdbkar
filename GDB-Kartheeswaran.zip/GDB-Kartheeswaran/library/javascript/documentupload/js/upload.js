//patient document viewer and upload
var currentpatientid;
Dropzone.autoDiscover = false;
$("#patientlist").on("click", ".getpatient", function () {
    window.localStorage.setItem("currentpatientid", this.id);

    currentpatientid = localStorage.getItem('currentpatientid');
    window.location.href = 'patientdocuploadview.html';
});
(function () {
        var upload = document.getElementById("upload"),
                authToken = localStorage.getItem('access_token'),
                //ServerURL = getResourceServerURL() + 'http://localhost:8085/';
                clear = document.getElementById("clear"),
//            aetField = aeTitle;
                dropzone = new Dropzone(".dropzone", {
                    url: '/doc/upload?access_token=' + authToken + '&id=' + localStorage.getItem('currentpatientid'),
                    uploadMultiple: true,
                    autoProcessQueue: false,
                    addRemoveLinks: true,
                    parallelUploads: 1000
                });
    

    upload.onclick = function () {
        var description = $("#description").val();
        if (description !== "") {
            $("#descriptionfail").text("");
            $("#descriptionfail").hide();
            var queuedFiles = dropzone.getQueuedFiles();
            if (!(queuedFiles.length > 0)) {
                return;
            }
            var url;
            //Import DICOM only
            url = '/doc/upload?access_token=' + authToken + '&id=' + localStorage.getItem('currentpatientid')+ '&desc=' +description;
            dropzone.options.url = url;
            dropzone.processQueue();
        } else {
            $("#descriptionfail").text("Please give a file description");
            $("#descriptionfail").show();
            
        }

    };
    clear.onclick = function () {
        dropzone.removeAllFiles(false);
    };
}
());
