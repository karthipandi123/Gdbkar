/* [ ---- Gebo Admin Panel - wizard ---- ] */
$(document).ready(function () {
    //* simple wizard
    gebo_wizard.simple();
    //* wizard with validation
    gebo_wizard.validation();
    //* add step numbers to titles
    gebo_wizard.steps_nb();
});
gebo_wizard = {
    simple: function () {
        $('#simple_wizard').stepy({
            titleClick: true,
            nextLabel: 'Next <i class="glyphicon glyphicon-chevron-right"></i>',
            backLabel: '<i class="glyphicon glyphicon-chevron-left"></i> Back'
        });
    },
    validation: function () {
        $('#validate_wizard').stepy({
            nextLabel: 'Forward <i class="glyphicon glyphicon-chevron-right"></i>',
            backLabel: '<i class="glyphicon glyphicon-chevron-left"></i> Backward',
            block: true,
            errorImage: true,
            titleClick: true,
            validate: true
        });
        stepy_validation = $('#validate_wizard').validate({
            onkeyup: false,
            errorClass: 'error',
            validClass: 'valid',
            highlight: function (element) {
                $(element).closest('div').addClass("f_error");
            },
            unhighlight: function (element) {
                $(element).closest('div').removeClass("f_error");
            },
            errorPlacement: function (error, element) {
                $(element).closest('div').append(error);
            },
           rules: {
               
                'doctormiddlename':{
                    required: true,
                         email: true
                },
                doctorlname:{
          required:true,
      minlength:10,
                    maxlength:10,
      number:true
      
      
      },
                'doctoraddress': {
                    required: true,
                    minlength:8
                    
                },
                'doctorphoneno': {
                    required: true,
                    minlength:8,
                    equalTo:"#doctoraddress"
                
                }
        
            },
            invalidHandler: function (form, validator) {
                $.sticky("There are some errors. Please corect them and submit again.", {autoclose: 5000, position: "top-right", type: "st-error"});
            },
            messages: {
                "doctormiddlename": {required: "Email is required!"},
                'doctorlname': {required: 'Mobile Number  is required!'},
                'doctoraddress': {required: 'Password is requerid!'},
                'doctorphoneno': {required: 'Confirm and Enter correct password!'},
            
        }
        });
    },
    //* add numbers to step titles
   
};